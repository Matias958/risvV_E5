#!/usr/bin/env bash
# Instala lo necesario para las simulaciones (Ubuntu / WSL). Pide la clave de sudo.
set -e
sudo apt-get update
sudo apt-get install -y make python3 iverilog gtkwave \
    gcc-riscv64-unknown-elf binutils-riscv64-unknown-elf
echo
echo "Listo. Verificando:"
make -C "$(dirname "$0")" entorno
