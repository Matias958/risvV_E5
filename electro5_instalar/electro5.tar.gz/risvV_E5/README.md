# ERV26 — 25.30 Electrónica V

Procesador RISC-V RV32I con pipeline de 5 etapas para la DE10-Nano (Cyclone V).

- **MVP-0** (checkpoint 1): proto-procesador single-cycle → `rtl/erv26_mvp0.v`, `quartus/`
- **Pipeline** (5 etapas): → `rtl/erv26_core.bdf` (núcleo por bloques), proyecto `risvV_E5.qpf`

## Estructura

```
rtl/
  erv26_defs.vh            opcodes, códigos de ALU, formatos
  erv26_decoder.v          campos + señales de control (instr_flags)
  erv26_imm_gen.v          IMM builder (I/S/B/U/J con extensión de signo)
  erv26_regfile.v          31 registros + x0; WRITE_THROUGH=1 en el pipeline
  erv26_operand_build.v    muxes de operandos A (rs1/PC/0) y B (rs2/imm)
  erv26_alu.v              ADD SUB SLL SLT SLTU XOR SRL SRA OR AND
  erv26_branch_unit.v      comparador + sumadores de salto (EX)
  erv26_forward_unit.v     forwarding EX/MEM y MEM/WB -> EX
  erv26_hazard_unit.v      control de pipeline y halt (freeze, load-use, flush)
  erv26_lsu.v              byte enables / extensión de signo de loads
  erv26_pc_select.v        IF: próxima dirección de fetch (freeze/branch/stall/JAL/+4)
  erv26_if_id.v            latch IF/ID
  erv26_id_predict.v       ID: destino de JAL y predicción de saltos BTFN
  erv26_id_ex.v            latch ID/EX (burbujas por load-use y flush)
  erv26_ex_result.v        EX: resultado (ALU o PC+4 para JAL/JALR)
  erv26_ex_mem.v           latch EX/MEM
  erv26_mem_ctrl.v         MEM: handshake memory_ready y protección contra doble acceso
  erv26_wb_select.v        MEM: dato de write-back (load o resultado)
  erv26_mem_wb.v           latch MEM/WB
  erv26_wb_commit.v        WB: enable del banco y salida de debug
  erv26_core.bdf           núcleo con pipeline: diagrama de bloques que conecta todo lo anterior
  legacy/erv26_core_v1.v   versión anterior del núcleo en un solo Verilog (solo referencia)
  erv26_imem.v             memoria de programa M10K (lectura sincrónica)
  erv26_dmem.v             memoria de datos M10K con memory_ready y lectura anticipada
  erv26_fetch.v, erv26_prog_mem.v, erv26_mvp0.v     (MVP-0)
  board/                   tops de DE10-Nano, control de placa, bus, E/S mapeada en memoria,
                           video HDMI (erv26_video), configuración del ADV7513 (erv26_hdmi_init)
tools/
  erv26asm.py              ensamblador propio (MVP-0)
  erv26_iss.py             modelo de referencia RV32I (golden model)
  elf2hex.py               ELF -> archivos de inicialización
  bdf2v.py                 .bdf de Quartus -> Verilog, para simular el top por bloques
sw/
  build.py                 compila C/asm -> imem.hex, dmem_b*.hex, .mif, .lst
  common/                  crt0.S, link.ld, erv26.h, entorno para riscv-tests
  demo/leds.c              demo de LEDs
  games/invaders/          juego "Invasores del espacio" (video HDMI, botones en GPIO)
  tests/*.c                programas de prueba en C
  tests/*.S                tests dirigidos en assembler (p.ej. casos borde de la predicción de saltos)
sim/
  run_tests.py             regresión del MVP-0
  run_core_tests.py        regresión del pipeline
  tb_core.v, tb_board.v, tb_mvp0.v
risvV_E5.qpf/.qsf/.bdf          proyecto de placa (raíz): top .bdf, .qsf (pines DE10-Nano), .sdc, programa
quartus/, quartus_pipeline/   MVP-0 y top de referencia en Verilog
```

## Requisitos

- Icarus Verilog (`iverilog`, `vvp`) y Python 3
- Toolchain RISC-V: `riscv64-unknown-elf-gcc` (en Ubuntu: `apt install gcc-riscv64-unknown-elf`). Compila para RV32I con `-march=rv32i -mabi=ilp32`.
- Para los tests oficiales: `git clone https://github.com/riscv-software-src/riscv-tests` al lado de la carpeta `erv26/`.

---

## Pipeline

```
         IF            ID                 EX                  MEM              WB
      ┌──────┐  ┌──────────────┐  ┌──────────────────┐  ┌─────────────┐  ┌─────────┐
 PC ─►│ imem │─►│ decode, imm  │─►│ forwarding ─► ALU │─►│ LSU ◄─► dmem│─►│ regfile │
      │(M10K)│  │ regfile read │  │ branch unit       │  │ memory_ready│  │  write  │
      └──────┘  │ JAL          │  └──────────────────┘  └─────────────┘  └─────────┘
         ▲      └──────────────┘          │  ▲  ▲              │              │
         │              │ JAL target      │  │  └─── fwd ──────┘              │
         └──────────────┴─────────────────┘  └────────── fwd ─────────────────┘
                      branch/JALR target
```

### Decisiones de diseño

**Fetch con M10K sin ciclo extra.** El núcleo entrega la dirección de la *próxima* instrucción (`imem_addr = f_pc`) y la M10K la registra en el flanco. Su salida es directamente la instrucción del latch IF/ID. Para mantener una instrucción en ID durante un stall se vuelve a pedir la misma dirección. Así la memoria de programa usa bloques M10K (sincrónicos) sin agregar una etapa.

**Resolución de saltos**, con predicción estática BTFN ("hacia atrás tomado, hacia adelante no tomado"):

| Caso | Predicción (ID) | Se verifica en | Ciclos perdidos |
|---|---|---|---|
| JAL | siempre tomado (destino PC+imm, sin registros) | — | 0 |
| Branch hacia atrás (offset < 0) | tomado: el fetch salta al destino desde ID | EX | 0 si se toma, 1 si no |
| Branch hacia adelante (offset ≥ 0) | no tomado: sigue en PC+4 | EX | 0 si no se toma, 1 si se toma |
| JALR | — (depende de un registro) | EX | 1 |
| Load seguido de uso | — | stall en ID | 1 |

Los loops compilados cierran con un branch hacia atrás que casi siempre se toma, así que BTFN elimina la penalidad en cada vuelta y solo se paga al salir del loop. `erv26_id_predict` reutiliza el sumador PC+imm del JAL; el bit `pred_taken` viaja por ID/EX y `erv26_branch_unit` lo compara con el resultado real (si se predijo tomado y no se toma, corrige a PC+4). Con predicción "no tomado" pura, `sort_crc.c` perdía 2 105 ciclos en saltos; con BTFN pierde 1 222.

Comparador y sumadores de salto van separados de la ALU (`erv26_branch_unit`). Cuestan un sumador y un comparador extra, pero el salto se resuelve en paralelo con la ALU y la penalidad baja a un ciclo.

**Hazards de datos.**
- **Forwarding** desde EX/MEM y MEM/WB hacia EX, para ambos operandos y para el dato de los stores.
- **Bypass WB→ID** dentro del banco (`WRITE_THROUGH=1`). Equivale a escribir en la primera mitad del ciclo y leer en la segunda, pero sin usar el flanco descendente.
- **Load-use:** un único stall de 1 ciclo. Después de ese ciclo el dato llega por forwarding desde WB.

**Control de pipeline y halt** (`erv26_hazard_unit`):
- **`freeze`:** congela PC y las 4 etapas. Se activa con `en=0` (halt externo o paso a paso) o con un acceso a memoria sin `memory_ready`.
- **`load_use`:** detiene PC e IF/ID, e inserta una burbuja en ID/EX.
- **`flush_id`:** una corrección en EX (branch mal predicho o JALR) descarta la instrucción que está en ID.

**Memoria de datos con `memory_ready`.** Protocolo req/ready: el núcleo mantiene `req`, `addr`, `we`, `be` y `wdata` estables hasta ver `ready`. Si `ready` llega en un ciclo en que el pipeline está congelado por otro motivo (`en=0`), el núcleo recuerda que el acceso ya se hizo y guarda el dato. Sin esto, un store se ejecutaría dos veces, cosa grave con periféricos (por ejemplo, una UART mandaría dos caracteres). Este bug lo encontraron los tests con halt aleatorio.

**Lectura anticipada de la memoria de datos.** La M10K registra la dirección en el flanco y entrega el dato en el ciclo siguiente. Si la dirección llegara recién con el load en MEM, cada load esperaría un ciclo. Para evitarlo, el núcleo da una salida extra, `dmem_addr_next`: la dirección que va a tener la instrucción de MEM en el ciclo siguiente. Es la del load que está en EX o, si el pipeline está congelado, la misma de MEM (`erv26_mem_ctrl`). La memoria lee esa dirección por adelantado y, cuando el load llega a MEM, el dato ya está listo. Es el mismo truco que usa el fetch con la memoria de programa.

`erv26_dmem` confirma `ready` solo si la dirección que leyó coincide con la del acceso y si esa lectura no chocó con una escritura a la misma palabra en el mismo flanco. En la M10K, leer y escribir la misma palabra a la vez da un valor indefinido (Quartus la infiere con read-during-write "don't care"). En ese caso, o si la dirección no coincidiera, la memoria tarda un ciclo más, pero nunca entrega un dato equivocado. Solo pasa cuando un load lee la palabra que el store anterior está escribiendo.

**Clock único con enables.** En lugar de los 5 clocks desfasados 72° sugeridos para la primera prueba, todo usa el mismo clock y el avance se controla con `freeze` y `en`. Es lo que pide el diseño final (todas las etapas en fase) y evita generar clocks con lógica en la FPGA.

**E/S mapeada en memoria** (base `0x8000_0000`) en vez de atar x28–x31 a puertos: gcc usa esos registros (t3–t6) libremente, así que reservarlos rompería el código compilado.

**Instrucciones no soportadas.** FENCE se ejecuta como NOP. SYSTEM (ECALL, EBREAK, CSR) es NOP con `is_system=1`, lista para la Parte III. Las instrucciones ilegales son NOP con `illegal=1`. Los accesos desalineados no generan trap.

### Mapa de memoria

| Dirección | Contenido |
|---|---|
| `0x0000_0000` | memoria de programa, 16 KB (`.text`) |
| `0x0001_0000` | memoria de datos, 16 KB (`.rodata`, `.data`, `.bss`, pila) |
| `0x8000_0000` | LEDs (en simulación: TOHOST, fin del test) |
| `0x8000_0004` | switches (en simulación: PUTCHAR) |
| `0x8000_0008` | contador de ciclos |
| `0x8000_000C` | botones (GPIO_0[3:0], 1 = apretado) |
| `0x8000_0010` | contador de cuadros de video (60 Hz) |
| `0x8000_0014` | página del framebuffer que se muestra |
| `0x4000_0000` | framebuffer de video: 2 páginas de 320×240, 1 byte por píxel RGB332 (solo escritura) |

Arquitectura Harvard con un único espacio de direcciones: `.rodata` va a la memoria de datos para que los loads la puedan leer.

### Verificación

```
cd sim
python3 run_core_tests.py                      # riscv-tests + C + 100 aleatorios
python3 run_core_tests.py --suite random --random 500
python3 run_core_tests.py --only rv32ui-lw --vcd
python3 run_core_tests.py -j 2                 # en paralelo
```

Cada programa se corre en el modelo de referencia (`tools/erv26_iss.py`) y en el RTL. Se compara **instrucción por instrucción** (PC, instrucción, registro y valor escritos) y la secuencia completa de stores. Cada programa se simula en cinco condiciones:

| Condición | memory_ready | en (halt) |
|---|---|---|
| `lat0` | siempre listo | siempre 1 |
| `lat3` | latencia aleatoria de 0 a 3 ciclos | siempre 1 |
| `lat2+halt` | latencia aleatoria de 0 a 2 ciclos | aleatorio |
| `m10k` | la RAM real de la placa (`erv26_dmem`, M10K con lectura anticipada) | siempre 1 |
| `m10k+halt` | la RAM real de la placa | aleatorio |

Mientras la memoria no responde, el testbench le entrega basura al núcleo, así que usar un dato antes de `ready` se detecta. En las condiciones `m10k`, si la M10K leyó y escribió la misma palabra en el mismo flanco, el testbench reemplaza su dato por `DEADBEEF`, así que usar ese valor indefinido también se detecta.

| Suite | Contenido | Resultado |
|---|---|---|
| riscv-tests rv32ui | 40 tests oficiales (no se corren `fence_i`, que es código auto-modificable, ni `ma_data`, de accesos desalineados). Incluyen los tests de bypass con 0, 1 y 2 instrucciones intermedias. | 40/40 |
| C | quicksort, CRC32, recursión, punteros a función, mul/div por software (libgcc), accesos de 8 y 16 bits | 2/2 |
| asm dirigidos | `branch_pred.S` (8 casos borde de la predicción) y `mem_access.S` (8 casos de store seguido de load a la misma palabra, punteros encadenados y copias solapadas) | 2/2 |
| aleatorios | branches, loops, JAL/JALR, loads/stores, load-use y dependencias densas | 100/100 (+500) |

Para comprobar que la regresión detecta errores, se inyectaron a propósito 8 bugs típicos de pipeline, uno por vez. **Todos fueron detectados:**

| Bug inyectado | Tests que pasan (de 62) |
|---|---|
| sin forwarding desde MEM | 0 |
| sin forwarding desde WB | 0 |
| sin stall load-use | 34 |
| sin flush en salto tomado | 1 |
| sin bypass WB→ID | 2 |
| sin protección contra doble acceso | 33 |
| store sin forwarding del dato | 0 |
| BGE invertido | 44 |

Para la lectura anticipada se inyectaron 3 bugs más:

| Bug inyectado | Resultado |
|---|---|
| `ready` sin chequear el choque lectura/escritura | `mem_access` falla: lee `DEADBEEF` |
| dirección anticipada sin tener en cuenta `freeze` | `mem_access` falla por timeout (la memoria nunca confirma) |
| sin lectura anticipada | pasa, pero con la RAM real tarda 8,6 % más: así se mide la mejora |

`tb_board.v` simula el top de placa completo (núcleo, M10K, bus y E/S) corriendo la demo compilada con `-DSIM`.

### Simulación gate-level (netlist de Quartus)

La regresión también puede correr sobre el circuito que genera Quartus en lugar del RTL. Así se comprueba que la síntesis interpretó bien el `.bdf` y el Verilog: conexiones, `$readmemh`, `initial`, RAMs inferidas.

1. Abrir `gate_sim/core_gl.qpf` en Quartus y compilar. Es un proyecto aparte, que no toca `risvV_E5`: compila solo `erv26_core` con sus puertos como pines virtuales y el EDA Netlist Writer deja `gate_sim/simulation/questa/core_gl.vo`.
2. Correr:

```
cd sim
python3 run_core_tests.py -j 2 --gate ../gate_sim/simulation/questa/core_gl.vo \
    --simlib <instalación de Quartus>/quartus/eda/sim_lib
```

Con `--gate` el testbench se compila con `-DGATE`: se desactivan los asserts que miran señales internas (en el netlist ya no existen) y la comparación contra el ISS se hace igual, por los puertos `dbg_commit_*`. `sim/gate_stubs.v` modela el buffer de reloj global (`cyclonev_clkena`), que en la librería viene encriptado. Es una simulación funcional: para Cyclone V, Quartus no genera netlists con retardos, y el timing lo verifica el Timing Analyzer. Con Icarus es lenta (unos 55 ciclos/s por proceso).

Último resultado, con la predicción BTFN y la lectura anticipada: 74/74 en las 5 condiciones (40 riscv-tests, 2 en C, 2 dirigidos y 30 aleatorios, con `--random 30`), con los mismos ciclos que el RTL. En el modo `--gate` la RAM de las condiciones `m10k` es el RTL de `erv26_dmem`; lo que se prueba a nivel compuertas es el núcleo.

### Performance (simulación, memoria sin espera)

| Programa | Ciclos / instrucciones | CPI |
|---|---|---|
| `arith.c` | 19 275 / 18 157 | 1,06 |
| `sort_crc.c` | 19 467 / 17 851 | 1,09 |

Con predicción "no tomado" pura daban 19 599 (CPI 1,08) y 20 350 (CPI 1,14).

Con la RAM real de la placa (condición `m10k`) los ciclos son los mismos: gracias a la lectura anticipada, los loads no esperan. Sin ella, cada load sumaba un ciclo y daban 21 088 (CPI 1,16) y 21 305 (CPI 1,19).

## En la placa

El proyecto para la placa es la raíz del repo (`risvV_E5.qpf`) (top-level por bloques, como pide la cátedra):

```
python3 sw/build.py sw/demo/leds.c        # deja imem.hex y dmem_b*.hex en la raíz
```

Programas ya compilados en `programas/` (`leds`, `invaders`). Para cambiar sin compilar C, desde la carpeta del proyecto:

```
cambiar_programa.bat leds        # o: cambiar_programa.bat invaders
```

y recompilar en Quartus (el programa queda dentro del `.sof`).

1. Abrir `risvV_E5.qpf` en Quartus.
2. Verificar los pines contra el System Builder de Terasic. Compilar y programar.

`risvV_E5.bdf` tiene ocho bloques conectados por nombre de red:

| Bloque | Función |
|---|---|
| `erv26_board_ctrl` | reset (KEY0) y halt (KEY1) sincronizados |
| `erv26_core` | núcleo con pipeline; es otro `.bdf` (`rtl/erv26_core.bdf`) con 19 bloques ordenados por etapa |
| `erv26_imem` | memoria de programa M10K, 16 KB |
| `erv26_bus` | decodificación del bus de datos: RAM o E/S según `addr[31]` |
| `erv26_dmem` | memoria de datos M10K, 16 KB |
| `erv26_io` | LEDs, switches y contador de ciclos |

Los `.bsf` de cada bloque están en la carpeta del proyecto. Las fuentes se toman de `rtl/`, las mismas que simula la regresión. `rtl/board/de10nano_erv26_top.v` es el mismo conexionado en Verilog (proyecto `quartus_pipeline/`, solo como referencia).

Los dos diagramas son la fuente de verdad: la regresión (`sim/run_core_tests.py`) convierte `rtl/erv26_core.bdf` a Verilog antes de simular, así que se prueba el mismo diagrama que sintetiza Quartus. Si se edita un `.bdf`, `tools/bdf2v.py` lo convierte a Verilog (avisa entradas sueltas y redes con dos drivers) para correr `sim/tb_board.v` sobre el diagrama:

```
python3 tools/bdf2v.py risvV_E5.bdf risvV_E5 /tmp/risvV_E5_bdf.v
```

## Video HDMI y juego

La placa saca video por HDMI a 640×480 a 60 Hz con su transmisor ADV7513:

- `erv26_video` genera el timing VESA con un píxel de 25 MHz (el reloj de 50 MHz dividido por 2, todo en el mismo dominio de reloj) y lee un framebuffer doble en M10K: 2 páginas de 320×240 a 1 byte por píxel (RGB332), mostradas duplicadas. El procesador dibuja en una página mientras se ve la otra, y cambia de página escribiendo `0x8000_0014`; el cambio se aplica al empezar el blanking vertical, así nunca se ve una imagen a medio dibujar.
- `erv26_hdmi_init` configura el ADV7513 por I2C (registros de la ADV7513 Programming Guide) y repite la configuración cada ~0,7 s, así funciona aunque el cable se enchufe después.

El programa cargado en la placa es **Invasores del espacio** (`sw/games/invaders/`), un juego estilo arcade con gráficos y fuente propios:

```
python3 sw/build.py sw/games/invaders/invaders.c -I sw/games/invaders
```

Botones en el conector GPIO_0 (JP1), cada uno entre el pin y GND (JP1 pin 12 o 30). Las entradas tienen pull-up interno, no hace falta ninguna resistencia:

| Pin de JP1 | Señal | Función |
|---|---|---|
| 1 | GPIO_0[0] | izquierda |
| 2 | GPIO_0[1] | derecha |
| 3 | GPIO_0[2] | disparo |
| 4 | GPIO_0[3] | start |

Los LEDs muestran las vidas. El juego usa ~17 % del tiempo de cada cuadro, así que siempre va a 60 fps.

Verificación del video y del juego:
- `sim/video/tb_video.v`: llena las dos páginas con patrones, captura dos cuadros y los compara píxel a píxel con lo esperado; mide el timing (800×525, sincronismos de 96 píxeles y 2 líneas, 640×480 activos).
- `sim/video/tb_i2c.v`: decodifica el bus I2C y lista las escrituras al ADV7513.
- El juego compila también para la PC (`gcc -O2 -DHOST -I. -o invaders invaders.c host_main.c` en su carpeta), juega una partida guionada y guarda imágenes.
- Simulando la placa completa con el juego, la imagen HDMI del ERV26 coincide píxel a píxel con la de la versión de PC.

Controles de la demo:
- **KEY0:** reset.
- **KEY1 mantenido:** halt.
- **SW[1:0]:** patrón (contador, "auto fantástico", llenado, Fibonacci).
- **SW[2]:** velocidad.
- **SW[3]:** pausa.

El reloj es de 50 MHz. En Quartus cierra con +4,6 ns de slack (Fmax ≈ 65 MHz); el `.sdc` restringe también los pines de E/S. Los caminos más largos son el redireccionamiento de saltos: salida de la M10K → decode → sumador de JAL → dirección de la M10K, y forwarding → comparador → dirección de la M10K.

## Simulaciones para clase

`clase/` tiene un `Makefile` con demos listas para mostrar, con las ondas en GTKWave: el pipeline con las instrucciones desensambladas en cada etapa (`make pipeline`), cualquier test (`make test T=...`), la placa con los LEDs, el video HDMI, el I2C, el juego y la simulación gate-level. Ver `clase/LEEME.md`.

`clase/modelsim/` tiene los mismos ejemplos como scripts de ModelSim (`do pipeline.do`, `do regresion.do`, `do gate.do`...), con el desensamblado de cada etapa en las ondas. Ver `clase/modelsim/LEEME.md`.

## MVP-0

`python3 sim/run_tests.py` corre la regresión del single-cycle con el ensamblador propio (`tools/erv26asm.py`). El top de placa es `rtl/board/de10nano_mvp0_top.v` y el proyecto está en `quartus/`.

## Próximos pasos (Parte III)

- CSRs CYCLE, TIME e INSTRET, y traps (necesarios para los juegos y para compiladores comerciales).
- Extensión M: multiplicador en bloques DSP y divisor multiciclo, que usa `freeze`.
- Stack de direcciones de retorno (RAS) en ID para JALR.
- UART y video.
